DEVICE:


OS version:


**cSploit version:**


**busybox** *(installed or not):*


**Rooted with supersu?**


**logcat** *(filter it!):*
[How-to guide](https://forum.xda-developers.com/showthread.php?t=1726238)

------------------------------------------------------------------------------------------------------------------------------

**Daemon specific questions**

Go version:


OS:


Using Docker (incase of unofficial build.)

Actions performed:


Logs:
------------------------------------------------------------------------------------------------------------------------------

**Issue:**
*Remember to search for issues alike before creating new one!*

