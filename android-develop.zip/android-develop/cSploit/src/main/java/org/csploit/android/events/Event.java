package org.csploit.android.events;

/**
 * main event interface
 */
public interface Event {
}
